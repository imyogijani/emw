export default function Offers() {
    return(
        <>
         <h1> Special Offers</h1>
        </>
    )
}