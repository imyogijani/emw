export default function Menu() {
    return (
    <>
        <h1>Browse menu</h1>
    </>
    )
}