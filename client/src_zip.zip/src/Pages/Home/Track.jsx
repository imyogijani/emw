export default function Track() {
    return(
        <>
        <h1>Track Order</h1>
        </>
    )
}