import React from "react";
import "../../App.css";

const Products = () => {
  return (
    <div className="admin-products">
      <div className="admin-header">
        <h1>Products</h1>
      </div>
      <p>Manage your products here.</p>
      {/* Add your products content here */}
    </div>
  );
};

export default Products;
