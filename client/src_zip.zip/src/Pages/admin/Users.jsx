import React from "react";
import "../../App.css";

const Users = () => {
  return (
    <div className="admin-users">
      <div className="admin-header">
        <h1>Users</h1>
      </div>
      <p>Manage your users here.</p>
      {/* Add your users content here */}
    </div>
  );
};

export default Users;
