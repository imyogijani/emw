import React from "react";
import "../../App.css";

const Orders = () => {
  return (
    <div className="admin-orders">
      <div className="admin-header">
        <h1>Orders</h1>
      </div>
      <p>Manage your orders here.</p>
      {/* Add your orders content here */}
    </div>
  );
};

export default Orders;
