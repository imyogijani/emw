export default function Registration() {
    return(
        <>
        
        </>
    )
}
