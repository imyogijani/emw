/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import "./Menu.css";
import "./theme-override.css";
import { useCart } from "../../context/CartContext";
import { useNavigate } from "react-router-dom";
import { showErrorToast, showSuccessToast } from "../../utils/errorHandler";
import JumpingLoader from "../../Components/JumpingLoader";
import {
  Star,
  ShoppingCart,
  Filter,
  Grid,
  List,
  Search,
  ChevronDown,
  Truck,
  Shield,
} from "lucide-react";
import axios from "../../utils/axios";
import { processImageUrl } from "../../utils/apiConfig";
import { addToCartAPI } from "../../api/cartApi/cartApi";
import { trackEvent } from "../../analytics/trackEvent";

// Mall info configuration
const mallInfo = {
  name: "E-Mall World",
  description: "Your trusted online shopping destination",
  rating: 4.6,
  reviews: 125000,
  minOrder: "₹0",
  deliveryTime: "Same Day Delivery",
  phone: "+91-960-190-0290",
  website: "https://emallworld.com",
  address: "Serving Worldwide",
};

export default function Menu() {
  const [activeTab, setActiveTab] = useState("Electronics");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [viewMode, setViewMode] = useState("grid");
  const [sortBy, setSortBy] = useState("relevance");
  const [filterOpen, setFilterOpen] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 9000000000]);
  const [allProducts, setAllProducts] = useState([]); // holds original unfiltered list
  const [products, setProducts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [order, setOrder] = useState("asc");
  const [totalPages, setTotalPages] = useState(1);

  const { addToCart } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(timer);
  }, [activeTab]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const response = await fetchFilteredProducts({
          page: currentPage,
          limit: 5,
          categoryId: activeTab,
          search: searchQuery,
          sortBy,
          order,
          minPrice: priceRange[0],
          maxPrice: priceRange[1],
        });

        setProducts(response.products);
        setTotalPages(response.totalPages || 1);
      } catch (err) {
        console.error("Error fetching paginated products:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [currentPage, activeTab, searchQuery, sortBy, priceRange, order]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    trackEvent("browse_products_view", {
      user_id: user?._id,
      location: window.location.pathname,
    });
  }, []);

  const handleAddToCart = async (
    e,
    product,
    variant = null,
    sourcePage = "Browse_ProductPage"
  ) => {
    e.stopPropagation();

    // const user = JSON.parse(localStorage.getItem("user"));
    // console.log("User 1211431243", user);
    try {
      const user = JSON.parse(localStorage.getItem("user"));
      const userId = user?._id;

      if (!userId) {
        showErrorToast("User not logged in", "Menu - Authentication");
        return;
      }

      const productData = {
        productId: product._id,
        variantId: variant?._id,
        quantity: 1,
        price: variant?.finalPrice || product.finalPrice,
        image: variant?.image || product.image?.[0],
        // price: product.price,
        title: product.name,
        // image: product.image,
        discount: product.discount,
        color: variant?.color,
        size: variant?.size,
      };

      const response = await addToCartAPI(userId, productData);
      await trackEvent("add_to_cart", {
        user_id: userId,
        product_id: product._id,
        name: product.name,
        category: product.category?.name,
        quantity: 1,
        price:
          product.activeDeal?.dealPrice ?? product.finalPrice ?? product.price,
        discount: product.discount,
        source_page: sourcePage,
        location: window.location.pathname,
      });

      showSuccessToast(`${product.name} added to cart!`, "Menu - Add to Cart");
    } catch (err) {
      console.error("Add to cart error:", err);
      showErrorToast("Failed to add to cart.", "Menu - Add to Cart Error");
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} className="star-filled" size={14} fill="currentColor" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <Star key="half" className="star-half" size={14} fill="currentColor" />
      );
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="star-empty" size={14} />);
    }

    return stars;
  };

  const handleSortChange = (e) => {
    const value = e.target.value;

    if (value === "price-low") {
      setSortBy("price");
      setOrder("asc");
    } else if (value === "price-high") {
      setSortBy("price");
      setOrder("desc");
    } else if (value === "rating") {
      setSortBy("rating");
      setOrder("desc");
    } else if (value === "reviews") {
      setSortBy("reviews");
      setOrder("desc");
    } else {
      setSortBy("createdAt");
      setOrder("desc");
    }
  };

  // Modern ProductCard component with unified design system
  const ProductCard = ({ item, isListView = false }) => {
    const navigate = useNavigate();
    const [imageError, setImageError] = useState(false);
    const [imageLoading, setImageLoading] = useState(true);

    const handleImageLoad = () => {
      setImageLoading(false);
      setImageError(false);
    };

    const handleImageError = () => {
      setImageLoading(false);
      setImageError(true);
    };

    const getImageSrc = () => {
      if (imageError) {
        return "https://images.pexels.com/photos/6214360/pexels-photo-6214360.jpeg";
      }
      return processImageUrl(item.image) || "https://images.pexels.com/photos/6214360/pexels-photo-6214360.jpeg";
    };

    const handleProductClick = async () => {
      // Track the click event
      await trackEvent("view_product_card_click", {
        product_id: item._id,
        name: item.name,
        category: item.category.name,
        price:
          item.activeDeal && item.activeDeal.dealPrice
            ? item.activeDeal.dealPrice
            : item.finalPrice,
        location: window.location.pathname,
      });

      // Navigate to product detail page
      navigate(`/product/${item._id}`, { state: { item } });
    };

    const renderPrice = () => {
      const currentPrice = item.activeDeal?.dealPrice || item.finalPrice || item.price;
      const originalPrice = item.originalPrice || item.price;
      const hasDiscount = item.discount || (item.activeDeal && item.activeDeal.dealPrice < originalPrice);

      return (
        <div className="pricing-section">
          <span className="current-price">₹{currentPrice}</span>
          {hasDiscount && originalPrice > currentPrice && (
            <>
              <span className="original-price">₹{originalPrice}</span>
              <span className="discount-percent">({Math.round(((originalPrice - currentPrice) / originalPrice) * 100)}% off)</span>
            </>
          )}
        </div>
      );
    };

    return (
      <div
        className={`card-base ${isListView ? 'card-fluid' : 'card-medium'} product-card`}
        onClick={handleProductClick}
        style={{ cursor: 'pointer' }}
      >
        <div className={`card-image-container ${imageLoading ? 'loading' : ''}`}>
          <img
            src={getImageSrc()}
            alt={item.name}
            className="card-image"
            loading="lazy"
            style={{
              objectFit: "cover",
              display: imageLoading ? "none" : "block",
            }}
            onLoad={handleImageLoad}
            onError={handleImageError}
          />
          {item.discount && (
            <div className="card-badge discount pulse">-{item.discount}%</div>
          )}
          {item.prime && <div className="card-badge featured">Prime</div>}
          {item.activeDeal && <div className="card-badge sale">Deal</div>}
        </div>

        <div className="card-content">
          <h3 className="card-title">{item.name}</h3>
          
          <div className="product-rating-row" style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <div className="rating-stars">
              {renderStars(item.averageRating || 0)}
            </div>
            <span className="rating-value" style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              {item.averageRating || 0}
            </span>
            <span className="review-count" style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
              ({item.totalReviews || 0})
            </span>
          </div>

          {renderPrice()}

          <p className="card-description">
            {item.description || "Premium quality product with excellent features and reliable performance."}
          </p>

          <div className="delivery-info" style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: '12px' }}>
            {item.freeDelivery && (
              <span className="free-delivery" style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--primary-color)' }}>
                <Truck size={14} />
                FREE Delivery
              </span>
            )}
            <span className="delivery-date">Get it by tomorrow</span>
          </div>

          <div className="card-actions">
            <button
              className="card-action"
              onClick={(e) => {
                e.stopPropagation();
                handleAddToCart(e, item);
              }}
              title="Add to Cart"
            >
              <ShoppingCart size={16} />
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="loader-container">
          <JumpingLoader size="large" />
          <p>Loading products...</p>
        </div>
      );
    }

    if (products.length === 0) {
      return (
        <div className="under-development">
          <h3>🚧 No Products Found</h3>
          <p>Try adjusting your filters or search</p>
        </div>
      );
    }

    return (
      <div className={`products-container ${viewMode}`}>
        {products.map((item) => (
          <ProductCard
            key={item._id}
            item={item}
            isListView={viewMode === "list"}
          />
        ))}
      </div>
    );
  };

  const fetchFilteredProducts = async ({
    page = 1,
    limit = 12,
    search = "",
    sortBy = "price",
    order = "asc",
    minPrice = 0,
    maxPrice = 200000,
  }) => {
    try {
      const queryParams = new URLSearchParams();

      queryParams.set("page", page);
      queryParams.set("limit", limit);
      if (search && search.trim() !== "") queryParams.set("search", search);
      if (sortBy) queryParams.set("sortBy", sortBy);
      if (order) queryParams.set("order", order);
      if (minPrice !== undefined) queryParams.set("minPrice", minPrice);
      if (maxPrice !== undefined) queryParams.set("maxPrice", maxPrice);

      // Optional: backend ke liye extra populate flags
      queryParams.set("populateCategory", "true");
      queryParams.set("populateSubcategory", "true");

      const response = await axios.get(
        `/api/products?${queryParams.toString()}`
      );

      {
        /* const finalURL = `/api/products?${queryParams.toString()}`;
      console.log("🟢 Final API URL called:", finalURL); */
      }

      {
        /* console.log(`/api/products?${queryParams.toString()}`) */
      }
      return response.data;
    } catch (error) {
      console.error("Error fetching filtered products:", error);
      throw error;
    }
  };

  const handleFilterSubmit = async () => {
    try {
      setIsLoading(true);
      const response = await fetchFilteredProducts({
        page: currentPage,
        search: searchQuery,
        sortBy,
        minPrice: priceRange[0],
        maxPrice: priceRange[1],
      });

      setProducts(response.products);
      setTotalPages(response.totalPages);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="modern-menu-page">
      <div className="menu-header-section">
        <div className="mall-info">
          <h1>Browse Products</h1>
          <div className="mall-meta">
            <div className="rating-badge">
              <Star className="star-icon" size={16} fill="currentColor" />
              <span>{mallInfo?.rating}</span>
              <span>({mallInfo?.reviews?.toLocaleString()} reviews)</span>
            </div>
            <div className="delivery-badge">
              <Truck size={16} />
              <span>{mallInfo?.deliveryTime}</span>
            </div>
            <div className="security-badge">
              <Shield size={16} />
              <span>Secure Shopping</span>
            </div>
          </div>
        </div>
      </div>

      <div className="search-filter-bar">
        <div className="search-section">
          <div className="search-input-wrapper">
            <Search size={20} className="search-icon" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </div>
        </div>

        <div className="filter-controls">
          <button
            className="btn btn-medium btn-secondary filter-toggle"
            onClick={() => setFilterOpen(!filterOpen)}
          >
            <span className="sparkle"><Filter size={16} /></span>
            <span className="text">Filters</span>
            <ChevronDown size={16} className={filterOpen ? "rotated" : ""} />
          </button>
          <select onChange={handleSortChange} className="sort-dropdown">
            <option value="relevance">Sort by Relevance</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Customer Rating</option>
            <option value="reviews">Most Reviewed</option>
          </select>

          <div className="view-toggle-switch">
            <div className="switch-toggle-group">
              <button
                className={`btn btn-small ${viewMode === "grid" ? "btn-primary" : "btn-secondary"} switch-btn`}
                onClick={() => setViewMode("grid")}
                style={{ marginRight: "10px" }}
              >
                <span className="sparkle"><Grid size={26} /></span>
              </button>
              <button
                className={`btn btn-small ${viewMode === "list" ? "btn-primary" : "btn-secondary"} switch-btn`}
                onClick={() => setViewMode("list")}
              >
                <span className="sparkle"><List size={26} /></span>
              </button>
              <span
                className={`switch-slider ${
                  viewMode === "list" ? "slide-right" : ""
                }`}
              ></span>
            </div>
          </div>
        </div>
      </div>

      {filterOpen && (
        <div className="filters-panel">
          <div className="filter-group">
            <label>Price Range</label>
            <div className="price-range">
              <input
                type="number"
                value={priceRange[0]}
                onChange={(e) =>
                  setPriceRange([+e.target.value, priceRange[1]])
                }
                placeholder="Min"
              />
              <span>to</span>
              <input
                type="number"
                value={priceRange[1]}
                onChange={(e) =>
                  setPriceRange([priceRange[0], +e.target.value])
                }
                placeholder="Max"
              />
            </div>
          </div>
        </div>
      )}

      <div className="category-navigation">
        <div className="category-tabs">
          {[].map((cat) => (
            <button
              key={cat}
              className={`btn btn-small ${activeTab === cat ? "btn-primary" : "btn-secondary"} category-tab`}
              onClick={() => setActiveTab(cat)}
            >
              <span className="text">{cat}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="products-section">{renderContent()}</div>
      {totalPages > 1 && (
        <div className="pagination-container">
          <button
            className="btn btn-medium btn-secondary pagination-btn"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          >
            <span className="text">⬅ Prev</span>
          </button>

          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              className={`btn btn-medium ${
                currentPage === index + 1 ? "btn-primary" : "btn-secondary"
              } pagination-btn`}
              onClick={() => setCurrentPage(index + 1)}
            >
              <span className="text">{index + 1}</span>
            </button>
          ))}

          <button
            className="btn btn-medium btn-secondary pagination-btn"
            disabled={currentPage === totalPages}
            onClick={() =>
              setCurrentPage((prev) => Math.min(prev + 1, totalPages))
            }
          >
            <span className="text">Next ➡</span>
          </button>
        </div>
      )}

      <div className="info-cards-section">
        <div className="info-cards-grid">
          <div className="info-card">
            <h3>📋 Catalog Info</h3>
            <div className="info-item">
              <span className="label">Categories:</span>
              <span className="value">0</span>
            </div>
            <div className="info-item">
              <span className="label">Total Products:</span>
              <span className="value">0</span>
            </div>
            <div className="info-item">
              <span className="label">Prime Products:</span>
              <span className="value">0</span>
            </div>
          </div>

          <div className="info-card">
            <h3>⭐ Quality Assurance</h3>
            <div className="info-item">
              <span className="label">Average Rating:</span>
              <span className="value">4.6/5</span>
            </div>
            <div className="info-item">
              <span className="label">Verified Reviews:</span>
              <span className="value">
                {mallInfo?.reviews?.toLocaleString()}
              </span>
            </div>
            <div className="info-item">
              <span className="label">Return Policy:</span>
              <span className="value">30 Days</span>
            </div>
          </div>

          <div className="info-card">
            <h3>🚚 Delivery & Support</h3>
            <div className="info-item">
              <span className="label">Delivery Time:</span>
              <span className="value">{mallInfo?.deliveryTime}</span>
            </div>
            <div className="info-item">
              <span className="label">Support:</span>
              <span className="value">24/7 Available</span>
            </div>
            <div className="info-item">
              <span className="label">Locations:</span>
              <span className="value">Pan India</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
